/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date         Author      Notes
 * 2009-01-05   Bernard     first version
 * 2011-02-14   onelife     Modify for EFM32
 * 2011-06-17   onelife     Merge all of the C source code into cpuport.c
 * 2012-12-23   aozima      stack addr align to 8byte.
 * 2012-12-29   Bernard     Add exception hook.
 * 2013-07-09   aozima      enhancement hard fault exception handler.
 * 2019-07-03   yangjie     add __rt_ffs() for armclang.
 */

#include <rtthread.h>
#include <msp430.h>

struct exception_stack_frame
{
    rt_uint16_t pch_sr;
    rt_uint16_t pcl;
};

struct stack_frame
{
    rt_ubase_t r4;
    rt_ubase_t r5;
    rt_ubase_t r6;
    rt_ubase_t r7;
    rt_ubase_t r8;
    rt_ubase_t r9;
    rt_ubase_t r10;
    rt_ubase_t r11;
    rt_ubase_t r12;
    rt_ubase_t r13;
    rt_ubase_t r14;
    rt_ubase_t r15;
    struct exception_stack_frame exception_stack_frame;
    rt_ubase_t pc_exit;
};

/* flag in interrupt handling */
volatile rt_ubase_t rt_interrupt_from_thread, rt_interrupt_to_thread;
volatile rt_uint8_t rt_thread_switch_interrupt_flag;

/* exception hook */
static rt_err_t (*rt_exception_hook)(void *context) = RT_NULL;

/**
 * This function will initialize thread stack
 *
 * @param tentry the entry of thread
 * @param parameter the parameter of entry
 * @param stack_addr the beginning stack address
 * @param texit the function will be called when thread exit
 *
 * @return stack address
 */
rt_uint8_t *rt_hw_stack_init(void       *tentry,
                             void       *parameter,
                             rt_uint8_t *stack_addr,
                             void       *texit)
{
    struct stack_frame  *stack_frame;
    rt_uint8_t         *stk;

    /* ��ȡջ��ָ��
     rt_hw_stack_init �ڵ��õ�ʱ�򣬴���stack_addr����(ջ��ָ��)*/
     stk  = stack_addr + sizeof(rt_ubase_t);

     /* �ֽڶ��� */
     stk  = (rt_uint8_t *)RT_ALIGN_DOWN((rt_ubase_t)stk, RT_ALIGN_SIZE);

    /* stkָ����������ƶ�sizeof(struct stack_frame)��ƫ�� */
    stk -= sizeof(struct stack_frame);

    /* ��stkָ��ǿ��ת��Ϊstack_frame���ͺ�浽stack_frame */
    stack_frame = (struct stack_frame *)stk;

    /* ��stack_frameΪ��ʼ��ַ����ջ�ռ�������ڴ��ʼ��Ϊ0xddbf */
    stack_frame->r4 = 0xddbf;
    stack_frame->r5 = 0xddbf;
    stack_frame->r6 = 0xddbf;
    stack_frame->r7 = 0xddbf;
    stack_frame->r8 = 0xddbf;
    stack_frame->r9 = 0xddbf;
    stack_frame->r10 = 0xddbf;
    stack_frame->r11 = 0xddbf;

    stack_frame->r12 = (rt_ubase_t)parameter;
    stack_frame->r13 = 0;
    stack_frame->r14 = 0;
    stack_frame->r15 = 0;

    /* ��ʼ���쳣����ʱ�Զ�����ļĴ��� */
    stack_frame->exception_stack_frame.pch_sr  =  (((rt_uint32_t)tentry>>4) & 0xF000)|0x08;   /* sr��Ĭ�Ͽ����ж� */
    stack_frame->exception_stack_frame.pcl  =  (rt_uint16_t)((rt_uint32_t)tentry);

    /* �߳��˳��򷵻�ʱ��ַ */
    stack_frame->pc_exit = ((rt_ubase_t)texit);

    /* �����߳�ջָ�� */
    return stk;
}

/**
 * This function set the hook, which is invoked on fault exception handling.
 *
 * @param exception_handle the exception handling hook function.
 */
void rt_hw_exception_install(rt_err_t (*exception_handle)(void* context))
{
    rt_exception_hook = exception_handle;
}

#ifdef RT_USING_FINSH
static void usage_fault_track(void)
{
    rt_kprintf("usage fault\n");
}

static void bus_fault_track(void)
{
    rt_kprintf("bus fault\n");
}

static void mem_manage_fault_track(void)
{
    rt_kprintf("mem manage fault\n");
}

static void hard_fault_track(void)
{
    rt_kprintf("hard fault\n");
}
#endif /* RT_USING_FINSH */

struct exception_info
{
    rt_uint32_t exc_return;
    struct stack_frame stack_frame;
};

/*
 * fault exception handler
 */
void rt_hw_hard_fault_exception(struct exception_info * exception_info)
{
    extern long list_thread(void);

    if (rt_exception_hook != RT_NULL)
    {
        rt_err_t result;

        result = rt_exception_hook(exception_info);
        if (result == RT_EOK)
            return;
    }

    rt_kprintf("r04: 0x%08x\n", &exception_info->stack_frame->r4);
    rt_kprintf("r05: 0x%08x\n", &exception_info->stack_frame->r5);
    rt_kprintf("r06: 0x%08x\n", &exception_info->stack_frame->r6);
    rt_kprintf("r07: 0x%08x\n", &exception_info->stack_frame->r7);
    rt_kprintf("r08: 0x%08x\n", &exception_info->stack_frame->r8);
    rt_kprintf("r09: 0x%08x\n", &exception_info->stack_frame->r9);
    rt_kprintf("r10: 0x%08x\n", &exception_info->stack_frame->r10);
    rt_kprintf("r11: 0x%08x\n", &exception_info->stack_frame->r11);
    rt_kprintf("r12: 0x%08x\n", &exception_info->stack_frame->r12);
    rt_kprintf("r12: 0x%08x\n", &exception_info->stack_frame->r13);
    rt_kprintf("r12: 0x%08x\n", &exception_info->stack_frame->r14);
    rt_kprintf("r12: 0x%08x\n", &exception_info->stack_frame->r15);
    rt_kprintf(" sr: 0x%08x\n", &exception_info->stack_frame->exception_stack_frame.sr);
    rt_kprintf(" pc: 0x%08x\n", &exception_info->stack_frame->exception_stack_frame.pc);

    if(exception_info->exc_return & (1 << 2) )
    {
        rt_kprintf("hard fault on thread: %s\r\n\r\n", rt_thread_self()->name);

#ifdef RT_USING_FINSH
        list_thread();
#endif /* RT_USING_FINSH */
    }
    else
    {
        rt_kprintf("hard fault on handler\r\n\r\n");
    }

#ifdef RT_USING_FINSH
    hard_fault_track();
#endif /* RT_USING_FINSH */

    while (1);
}

/**
 * shutdown CPU
 */
void rt_hw_cpu_shutdown(void)
{
    rt_kprintf("shutdown...\n");

    RT_ASSERT(0);
}

/**
 * reset CPU
 */
RT_WEAK void rt_hw_cpu_reset(void)
{
    PMMCTL0 |= PMMSWPOR;
}

#ifdef RT_USING_CPU_FFS
#error MSP430 without CPU FFS
#endif
